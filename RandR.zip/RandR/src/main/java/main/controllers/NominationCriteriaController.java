package main.controllers;

import main.model.NominationCriteria;
import main.model.NominationCriteriaRemark;
import main.services.NominationCriteriaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/nominationCriteria")
public class NominationCriteriaController {

    @Autowired
    private NominationCriteriaService nominationCriteriaService;
    private String reward_type;

    /*  to save*/
    @PostMapping("/save")
    public NominationCriteriaRemark createEmployee(@Valid @RequestBody NominationCriteriaRemark nominationCriteriaRemark)
    {
        return nominationCriteriaService.save( nominationCriteriaRemark );
    }

/* to retrieve all details*/
    @GetMapping("/all")
    public List<NominationCriteriaRemark> getAll()
    {
        return nominationCriteriaService.findAll();
    }

/* to retrieve by id*/
    @GetMapping("/getByRewardType/{REWARD_TYPE}")
    public List<NominationCriteriaRemark> getId(@PathVariable("REWARD_TYPE") final String REWARD_TYPE)
    {
        return nominationCriteriaService.getId(REWARD_TYPE);
    }

/*  to update*/
    @PutMapping("/update")
    public NominationCriteriaRemark update(@RequestBody NominationCriteriaRemark nominationCriteriaRemark)
    {
        return  nominationCriteriaService.update( nominationCriteriaRemark );
    }

    @GetMapping("/all/{REWARD_TYPE}")
    public List<NominationCriteria> getAllCriteria(@PathVariable("REWARD_TYPE") final String REWARD_TYPE)
    {
        return nominationCriteriaService.getAllCriteria(REWARD_TYPE);
    }


}
