package main.repositories;

import main.model.NominationEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface NominationRepository extends JpaRepository<NominationEntity,Integer> {
    @Query("select n from NominationEntity n where n.NOMINEE_ID=?1")
    Optional<NominationEntity> findByNomineeid(Integer nominee_id);
}
