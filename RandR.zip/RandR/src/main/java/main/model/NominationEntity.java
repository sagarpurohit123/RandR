package main.model;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Table(name="nomination")
public class NominationEntity {

        @Id
        @GeneratedValue(strategy = GenerationType.AUTO)
        private Long ID;
        @OneToMany(fetch = FetchType.LAZY,mappedBy = "nomination")
        private List<NominationRemark> nominationRemarkList;

        private String NOMINEE_NAME;
        private Integer NOMINEE_ID;
        private String MANAGER_NAME;
        private Integer MANAGER_ID;
        private String NOMINATOR_NAME;
        private Integer NOMINATOR_ID;
        private String LOB;
        private String REWARD_TYPE;
        private String NOMINATION_STATUS;
        private Date NOMINATION_DATE;
        private Integer PMO_ID;


    //Getters and Setters and Constructor
    public NominationEntity() {
    }

    public Long getID() {
        return ID;
    }

    public void setID(Long ID) {
        this.ID = ID;
    }

    public List<NominationRemark> getNominationRemarkList() {
        return nominationRemarkList;
    }

    public void setNominationRemarkList(List<NominationRemark> nominationRemarkList) {
        this.nominationRemarkList = nominationRemarkList;
    }

    public String getNOMINEE_NAME() {
        return NOMINEE_NAME;
    }

    public void setNOMINEE_NAME(String NOMINEE_NAME) {
        this.NOMINEE_NAME = NOMINEE_NAME;
    }

    public Integer getNOMINEE_ID() {
        return NOMINEE_ID;
    }

    public void setNOMINEE_ID(Integer NOMINEE_ID) {
        this.NOMINEE_ID = NOMINEE_ID;
    }

    public String getMANAGER_NAME() {
        return MANAGER_NAME;
    }

    public void setMANAGER_NAME(String MANAGER_NAME) {
        this.MANAGER_NAME = MANAGER_NAME;
    }

    public Integer getMANAGER_ID() {
        return MANAGER_ID;
    }

    public void setMANAGER_ID(Integer MANAGER_ID) {
        this.MANAGER_ID = MANAGER_ID;
    }

    public String getNOMINATOR_NAME() {
        return NOMINATOR_NAME;
    }

    public void setNOMINATOR_NAME(String NOMINATOR_NAME) {
        this.NOMINATOR_NAME = NOMINATOR_NAME;
    }

    public Integer getNOMINATOR_ID() {
        return NOMINATOR_ID;
    }

    public void setNOMINATOR_ID(Integer NOMINATOR_ID) {
        this.NOMINATOR_ID = NOMINATOR_ID;
    }

    public String getLOB() {
        return LOB;
    }

    public void setLOB(String LOB) {
        this.LOB = LOB;
    }

    public String getREWARD_TYPE() {
        return REWARD_TYPE;
    }

    public void setREWARD_TYPE(String REWARD_TYPE) {
        this.REWARD_TYPE = REWARD_TYPE;
    }

    public String getNOMINATION_STATUS() {
        return NOMINATION_STATUS;
    }

    public void setNOMINATION_STATUS(String NOMINATION_STATUS) {
        this.NOMINATION_STATUS = NOMINATION_STATUS;
    }

    public Date getNOMINATION_DATE() {
        return NOMINATION_DATE;
    }

    public void setNOMINATION_DATE(Date NOMINATION_DATE) {
        this.NOMINATION_DATE = NOMINATION_DATE;
    }

    public Integer getPMO_ID() {
        return PMO_ID;
    }

    public void setPMO_ID(Integer PMO_ID) {
        this.PMO_ID = PMO_ID;
    }
}
