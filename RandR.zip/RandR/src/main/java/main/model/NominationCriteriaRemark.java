package main.model;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "nominationcriteria")
public class NominationCriteriaRemark {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Integer CRITERIA_ID;
    @OneToMany(fetch = FetchType.LAZY,mappedBy = "nominationcriteria")
    private List<NominationRemark> nominationRemarks;

    private String REWARD_TYPE;
    private String CRITERIA;

    //Getters and Setters and Constructor

    public NominationCriteriaRemark() {
    }

    public NominationCriteriaRemark(Integer CRITERIA_ID, String REWARD_TYPE, String CRITERIA) {
        this.CRITERIA_ID = CRITERIA_ID;
        this.REWARD_TYPE = REWARD_TYPE;
        this.CRITERIA = CRITERIA;
    }

    public Integer getCRITERIA_ID() {
        return CRITERIA_ID;
    }

    public void setCRITERIA_ID(Integer CRITERIA_ID) {
        this.CRITERIA_ID = CRITERIA_ID;
    }

    public List<NominationRemark> getNominationRemarks() {
        return nominationRemarks;
    }

    public void setNominationRemarks(List<NominationRemark> nominationRemarks) {
        this.nominationRemarks = nominationRemarks;
    }

    public String getREWARD_TYPE() {
        return REWARD_TYPE;
    }

    public void setREWARD_TYPE(String REWARD_TYPE) {
        this.REWARD_TYPE = REWARD_TYPE;
    }

    public String getCRITERIA() {
        return CRITERIA;
    }

    public void setCRITERIA(String CRITERIA) {
        this.CRITERIA = CRITERIA;
    }
}
