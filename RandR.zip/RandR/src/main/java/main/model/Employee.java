package main.model;

import java.text.DateFormat;

public class Employee {
    private int emp_id;
    private String emp_name;
    private  String reward_type;
    private String interview_type;
    private int no_of_hours;
    private int no_of_interviews;
    private int no_of_compoff;
    private int no_of_points;
    private DateFormat date_of;
    private int created_by;
    private int modified_by;
    private int manager_id;
    private String manager_name;

    public int getEmp_id() {
        return emp_id;
    }

    public void setEmp_id(int emp_id) {
        this.emp_id = emp_id;
    }

    public String getEmp_name() {
        return emp_name;
    }

    public void setEmp_name(String emp_name) {
        this.emp_name = emp_name;
    }

    public String getReward_type() {
        return reward_type;
    }

    public void setReward_type(String reward_type) {
        this.reward_type = reward_type;
    }

    public String getInterview_type() {
        return interview_type;
    }

    public void setInterview_type(String interview_type) {
        this.interview_type = interview_type;
    }

    public int getNo_of_hours() {
        return no_of_hours;
    }

    public void setNo_of_hours(int no_of_hours) {
        this.no_of_hours = no_of_hours;
    }

    public int getNo_of_interviews() {
        return no_of_interviews;
    }

    public void setNo_of_interviews(int no_of_interviews) {
        this.no_of_interviews = no_of_interviews;
    }

    public int getNo_of_compoff() {
        return no_of_compoff;
    }

    public void setNo_of_compoff(int no_of_compoff) {
        this.no_of_compoff = no_of_compoff;
    }

    public int getNo_of_points() {
        return no_of_points;
    }

    public void setNo_of_points(int no_of_points) {
        this.no_of_points = no_of_points;
    }

    public DateFormat getDate_of() {
        return date_of;
    }

    public void setDate_of(DateFormat date_of) {
        this.date_of = date_of;
    }

    public int getCreated_by() {
        return created_by;
    }

    public void setCreated_by(int created_by) {
        this.created_by = created_by;
    }

    public int getModified_by() {
        return modified_by;
    }

    public void setModified_by(int modified_by) {
        this.modified_by = modified_by;
    }

    public int getManager_id() {
        return manager_id;
    }

    public void setManager_id(int manager_id) {
        this.manager_id = manager_id;
    }

    public String getManager_name() {
        return manager_name;
    }

    public void setManager_name(String manager_name) {
        this.manager_name = manager_name;
    }


}
