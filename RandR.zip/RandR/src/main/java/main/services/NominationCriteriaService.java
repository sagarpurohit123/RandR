package main.services;

import main.model.NominationCriteria;
import main.model.NominationCriteriaRemark;
import main.repositories.NominationCriteriaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NominationCriteriaService {

    @Autowired
    private NominationCriteriaRepository nominationCriteriaRepository;

//To save

    public NominationCriteriaRemark save(NominationCriteriaRemark nominationCriteriaRemark) {
        return nominationCriteriaRepository.save( nominationCriteriaRemark );
    }

// retrieve all employeerole details
    public List<NominationCriteriaRemark> findAll() {
        return nominationCriteriaRepository.findAll();
    }

//    Get by an reward type
    public List<NominationCriteriaRemark> getId(String REWARD_TYPE) {
        return nominationCriteriaRepository.findByRewardType(REWARD_TYPE);
    }

// to update
    public NominationCriteriaRemark update(NominationCriteriaRemark nominationCriteriaRemark) {
        return nominationCriteriaRepository.save( nominationCriteriaRemark );
    }

    //    Get by an reward type
    public List<NominationCriteria> getAllCriteria(String REWARD_TYPE) {
        return nominationCriteriaRepository.getAllCriteria(REWARD_TYPE);
    }



}
