package main.services;

import main.model.EmployeeEntity;
import main.repositories.EmployeeRewardsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeRewardsService {

    @Autowired
    private EmployeeRewardsRepository employeeRewardsRepository;

    //   To save
    public EmployeeEntity save(EmployeeEntity employeeEntity) {
        return employeeRewardsRepository.save(employeeEntity);
    }

    // retrieve all employeerole details
    public List<EmployeeEntity> findAll() {
        return employeeRewardsRepository.findAll();
    }

    //    Get by employee id
    public List<EmployeeEntity> getId(Integer EMP_ID) {
        return employeeRewardsRepository.findByEmpId(EMP_ID);
    }

    //    Get by manager id
    public List<EmployeeEntity> getByManagerId(Integer EMP_ID) {
        return employeeRewardsRepository.findByManagerId(EMP_ID);
    }

    //    to update
    public EmployeeEntity update(EmployeeEntity employeeEntity) {
        return employeeRewardsRepository.save(employeeEntity);
    }

}
