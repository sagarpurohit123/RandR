package main.services;

import main.model.NominationRemark;
import main.repositories.NominationRemarkRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class NominationRemarkService {

    @Autowired
    private NominationRemarkRepository nominationRemarkRepository;

    /*    To save*/
    public NominationRemark save(NominationRemark nominationRemark) {
        return nominationRemarkRepository.save(nominationRemark);
    }

    /* retrieve all employeerole details*/

    public List<NominationRemark> findAll() {
        return nominationRemarkRepository.findAll();
    }

    /*    Get by an id*/

    public Optional<NominationRemark> getId(Long ID) {
        return nominationRemarkRepository.findById(ID);

    }

    /*    to update*/

    public NominationRemark update(NominationRemark nominationRemark) {
        return nominationRemarkRepository.save(nominationRemark);
    }
}
